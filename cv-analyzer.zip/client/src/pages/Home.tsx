import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { FileUp, BookOpen, Shield, BarChart3 } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">CV Analyzer</h1>
          <p className="text-muted-foreground mb-8">Sign in to analyze your CV and get personalized recommendations</p>
          <Button size="lg" onClick={() => navigate("/analyzer")}>
            Get Started
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-2">Welcome, {user?.name}!</h1>
          <p className="text-muted-foreground">Analyze your CV and discover your career potential</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <div
            className="border rounded-lg p-6 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => navigate("/analyzer")}
          >
            <FileUp className="h-8 w-8 mb-4 text-primary" />
            <h3 className="font-semibold mb-2">Analyze CV</h3>
            <p className="text-sm text-muted-foreground">Upload and analyze your resume</p>
          </div>

          <div
            className="border rounded-lg p-6 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => navigate("/documentation")}
          >
            <BookOpen className="h-8 w-8 mb-4 text-primary" />
            <h3 className="font-semibold mb-2">Documentation</h3>
            <p className="text-sm text-muted-foreground">Learn about our technology and approach</p>
          </div>

          <div
            className="border rounded-lg p-6 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => navigate("/ethics")}
          >
            <Shield className="h-8 w-8 mb-4 text-primary" />
            <h3 className="font-semibold mb-2">Ethics</h3>
            <p className="text-sm text-muted-foreground">Our commitment to fairness and transparency</p>
          </div>

          <div
            className="border rounded-lg p-6 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => navigate("/analyzer")}
          >
            <BarChart3 className="h-8 w-8 mb-4 text-primary" />
            <h3 className="font-semibold mb-2">History</h3>
            <p className="text-sm text-muted-foreground">View your past analyses</p>
          </div>
        </div>
      </div>
    </div>
  );
}
