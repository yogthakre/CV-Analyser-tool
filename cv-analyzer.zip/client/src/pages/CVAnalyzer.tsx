import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Spinner } from "@/components/ui/spinner";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { FileUp, Sparkles } from "lucide-react";
import { AnalysisDashboard } from "@/components/AnalysisDashboard";
import { AnalysisHistory } from "@/components/AnalysisHistory";

type AnalysisState = "upload" | "analyzing" | "results" | "history";

export default function CVAnalyzer() {
  const [state, setState] = useState<AnalysisState>("upload");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [targetRole, setTargetRole] = useState<string>("Data Scientist");
  const [fileContent, setFileContent] = useState<string>("");
  const [currentAnalysis, setCurrentAnalysis] = useState<any>(null);

  const rolesQuery = trpc.roles.list.useQuery();
  const uploadMutation = trpc.cv.upload.useMutation();

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error("File size must be less than 5MB");
      return;
    }

    setSelectedFile(file);

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setFileContent(content);
    };

    if (file.type === "application/pdf") {
      reader.readAsDataURL(file);
    } else {
      reader.readAsText(file);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedFile || !fileContent || !targetRole) {
      toast.error("Please select a file and target role");
      return;
    }

    setState("analyzing");
    try {
      const result = await uploadMutation.mutateAsync({
        fileContent,
        fileName: selectedFile.name,
        targetRole,
        isPdf: selectedFile.type === "application/pdf",
      });

      setCurrentAnalysis(result);
      setState("results");
      toast.success("CV analyzed successfully!");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Analysis failed");
      setState("upload");
    }
  };

  if (state === "results" && currentAnalysis) {
    return (
      <AnalysisDashboard
        analysis={currentAnalysis}
        onBack={() => setState("upload")}
        onViewHistory={() => setState("history")}
      />
    );
  }

  if (state === "history") {
    return (
      <AnalysisHistory
        onBack={() => setState("upload")}
        onSelectAnalysis={(analysis) => {
          setCurrentAnalysis(analysis);
          setState("results");
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary">
      <div className="container mx-auto px-4 py-12">
        <div className="mb-12 text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">AI-Powered Analysis</span>
          </div>
          <h1 className="mb-4 text-4xl font-bold tracking-tight text-foreground md:text-5xl">
            CV Analyzer
          </h1>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            Get intelligent insights into your professional profile. Discover your strengths, identify skill gaps, and
            receive personalized recommendations for career growth.
          </p>
        </div>

        <div className="mx-auto max-w-2xl">
          <Card className="border-2 shadow-lg">
            <CardHeader>
              <CardTitle>Upload Your CV</CardTitle>
              <CardDescription>
                Upload your resume in PDF or text format for instant analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="cv-file">Resume File</Label>
                <div className="flex items-center gap-4">
                  <Input
                    id="cv-file"
                    type="file"
                    accept=".pdf,.txt,.doc,.docx"
                    onChange={handleFileSelect}
                    disabled={state === "analyzing"}
                    className="flex-1"
                  />
                  {selectedFile && (
                    <span className="text-sm font-medium text-green-600">{selectedFile.name}</span>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="target-role">Target Job Role</Label>
                <Select value={targetRole} onValueChange={setTargetRole} disabled={state === "analyzing"}>
                  <SelectTrigger id="target-role">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {rolesQuery.data?.map((role) => (
                      <SelectItem key={role.id} value={role.name}>
                        {role.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-4 pt-4">
                <Button
                  onClick={handleAnalyze}
                  disabled={!selectedFile || state === "analyzing"}
                  size="lg"
                  className="flex-1"
                >
                  {state === "analyzing" ? (
                    <>
                      <Spinner className="mr-2 h-4 w-4" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <FileUp className="mr-2 h-4 w-4" />
                      Analyze CV
                    </>
                  )}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setState("history")}
                  size="lg"
                  disabled={state === "analyzing"}
                >
                  View History
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-3">
          <Card className="border-0 bg-white/50 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-lg">Profile Scoring</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Get a transparent breakdown of your profile score across multiple dimensions.
              </p>
            </CardContent>
          </Card>
          <Card className="border-0 bg-white/50 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-lg">Skill Gap Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Identify exactly which skills you have and which ones you need to develop.
              </p>
            </CardContent>
          </Card>
          <Card className="border-0 bg-white/50 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-lg">Smart Recommendations</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Receive personalized, actionable recommendations for career advancement.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
